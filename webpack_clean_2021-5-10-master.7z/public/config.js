// /public/config.js 除了以下的配置之外，这里面还可以有许多其他配置，例如,pulicPath 的路径等等
module.exports = {
  dev: {
    template: {
      title: 'devtemplate111',
      header: false,
      footer: false,
      publicPath: '/', 
      publicStaticPath: '../',
      assetsPath: 'assets/' // 开发测试用--可以切换路径
      // assetsPath: 'assets_All/' // 开发测试用--这里有很多用不到的模型以及图片，模型太大，为避免被打包，所以用这个了

    }
  },
  build: {
    template: { // 切记！！！！！打包上线之前要改一下webpack.config.js的161行代码
      title: '我的系统',
      header:true,
      footer:false,
      // publicPath: '/dist/', // 打包上线之前要改一下这个哦TODU-LIST
      // publicStaticPath: '/dist/', // 打包上线之前要改一下这个哦TODU-LIST
      // publicPath: '/BBBB/', // 打包上线之前要改一下这个哦TODU-LIST
      // publicStaticPath: '/BBBB/', // 打包上线之前要改一下这个哦TODU-LIST
      publicPath: '/AAAA/', // 打包上线之前要改一下这个哦TODU-LIST
      publicStaticPath: '/AAAA/', // 打包上线之前要改一下这个哦TODU-LIST,
      assetsPath: 'assets/'
    }
  }
}