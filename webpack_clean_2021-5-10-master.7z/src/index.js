
import './index.less'
import './js/clean.js'
import 'dsbridge_flutter'

dsBridge.call('share', { name: 'woyehaizaixiang' }, function (res) {
  alert(res)
})

class Word {
  constructor(mydata) {
    this.mydata = mydata
  }
  getMydata() {
    return this.mydata
  }
}
const start = new Word('项目已启动')
console.log(start)
