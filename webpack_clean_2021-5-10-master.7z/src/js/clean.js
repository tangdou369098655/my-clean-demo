console.log('clean.js')
document.getElementById('my_first_child').onclick = (e) => {
  document.getElementById('my_second_child').innerHTML=Math.random() * 100 + ''
}